import express from "express";

const app = express();
const PORT = process.env.PORT || 3000;
app.use(express.json({ limit: "1mb" }));
app.use(express.static("public"));

app.get("/api/status", (_req, res) => {
  res.json({ configured: Boolean(process.env.GEMINI_API_KEY) });
});

app.post("/api/chat", async (req, res) => {
  try {
    const apiKey = process.env.GEMINI_API_KEY;
    if (!apiKey) {
      return res.status(503).json({
        error: "لم تتم إضافة مفتاح Gemini بعد. اتبع ملف README لإعداده بأمان."
      });
    }

    const messages = Array.isArray(req.body.messages) ? req.body.messages : [];
    const contents = messages
      .filter(m => m && ["user", "model"].includes(m.role) && typeof m.text === "string")
      .slice(-20)
      .map(m => ({
        role: m.role,
        parts: [{ text: m.text.slice(0, 8000) }]
      }));

    if (!contents.length || contents[contents.length - 1].role !== "user") {
      return res.status(400).json({ error: "اكتب رسالة أولًا." });
    }

    const response = await fetch(
      "https://generativelanguage.googleapis.com/v1beta/models/gemini-2.5-flash:generateContent",
      {
        method: "POST",
        headers: {
          "Content-Type": "application/json",
          "x-goog-api-key": apiKey
        },
        body: JSON.stringify({
          systemInstruction: {
            parts: [{ text: "أنت Youcef AI، مساعد مفيد ولطيف. أجب بلغة المستخدم، واشرح للمبتدئ ببساطة. لا تدّعِ أنك ChatGPT أو أنك تعرف معلومات غير متاحة." }]
          },
          contents,
          generationConfig: { temperature: 0.7, maxOutputTokens: 1200 }
        })
      }
    );

    const data = await response.json();
    if (!response.ok) {
      const detail = data?.error?.message || "تعذر الاتصال بخدمة الذكاء الاصطناعي.";
      return res.status(response.status).json({ error: detail });
    }

    const answer = data?.candidates?.[0]?.content?.parts
      ?.map(p => p.text || "")
      .join("")
      .trim();

    if (!answer) return res.status(502).json({ error: "لم تصل إجابة نصية. حاول مرة أخرى." });
    res.json({ answer });
  } catch (err) {
    console.error("Chat API error:", err);
    res.status(500).json({ error: "حدث خطأ في الخادم. حاول لاحقًا." });
  }
});

app.listen(PORT, "0.0.0.0", () => {
  console.log(`Youcef AI is running on port ${PORT}`);
});
